//
//  SingUpViewController.swift
//  FirebaseSingUpAndLogin
//
//  Created by Md Hosne Mobarok on 8/3/22.
//

import UIKit
import Firebase
import FirebaseAuth

class SingUpViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    // MARK: - Private Methods.
    
    // MARK: - Button Action.
    @IBAction func signUpButtonAction(_ sender: UIButton) {
        if email.text == "" {
                let alertController = UIAlertController(title: "Error", message: "Please enter your email and password", preferredStyle: .alert)
                let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(defaultAction)
                present(alertController, animated: true, completion: nil)
            
            } else {
                
                guard let email = email.text else { return }
                guard let password = password.text else { return }
                
                Auth.auth().createUser(withEmail: email, password: password) { (user, error) in
                    
                    if error == nil {
                        print("You have successfully signed up")
                        
                        let storyboard = UIStoryboard(name: "Login", bundle: nil)
                        let vc = storyboard.instantiateViewController(withIdentifier: "LoginViewController")
                        vc.modalPresentationStyle = .fullScreen
                        self.present(vc, animated: true, completion: nil)
                        
                    } else {
                        
                        let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                        let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                        alertController.addAction(defaultAction)
                        self.present(alertController, animated: true, completion: nil)
                    }
                }
            }
    }
    
}
