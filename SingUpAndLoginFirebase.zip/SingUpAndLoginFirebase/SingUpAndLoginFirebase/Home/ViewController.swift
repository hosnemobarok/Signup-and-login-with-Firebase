//
//  ViewController.swift
//  FirebaseSingUpAndLogin
//
//  Created by Md Hosne Mobarok on 8/3/22.
//

import UIKit
import Firebase
import FirebaseAuth

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    // MARK: - Private Methods.
    
    // MARK: - Button Action
    @IBAction func logoutButtonAction(_ sender: UIButton){
        
        if Auth.auth().currentUser != nil {
            do {
                try Auth.auth().signOut()
                let storyboard = UIStoryboard(name: "Login", bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: "LoginViewController")
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: true, completion: nil)
                
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }
    }

}

